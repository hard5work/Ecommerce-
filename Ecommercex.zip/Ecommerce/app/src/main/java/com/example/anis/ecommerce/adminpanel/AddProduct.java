package com.example.anis.ecommerce.adminpanel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.anis.ecommerce.R;

public class AddProduct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
    }
}

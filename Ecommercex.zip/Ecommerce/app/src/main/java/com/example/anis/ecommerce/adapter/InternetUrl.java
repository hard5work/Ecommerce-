package com.example.anis.ecommerce.adapter;

import android.content.Context;
import android.telecom.InCallService;

import com.example.anis.ecommerce.login_stuff.SessionManager;

public class InternetUrl {


    public class ServiceTYpe {
        public static final String up = "http:/192.168.1.141/ecommerce/";
        public static final String lint = "http:/192.168.1.174/ecommerce/";
        public static final String home = "http:/192.168.100.143/ecommerce/";
        public static final String test = "http://192.168.1.64:8080/ecommerce/";
        public static final String online = "https://xdroid051.000webhostapp.com/Ecommerce/";
        //public final String changer = new SessionManager().getServerIP();
        public static final String URL = test;
    }



}
